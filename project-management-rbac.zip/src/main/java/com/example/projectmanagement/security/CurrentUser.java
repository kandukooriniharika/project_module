// package com.example.projectmanagement.security;

// import java.lang.annotation.*;

// @Target(ElementType.PARAMETER)
// @Retention(RetentionPolicy.RUNTIME)
// @Documented
// public @interface CurrentUser { }